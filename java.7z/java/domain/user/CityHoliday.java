package domain.user;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CityHoliday {
    String cityId;
}
