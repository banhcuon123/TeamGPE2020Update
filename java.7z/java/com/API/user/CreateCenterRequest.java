package com.API.user;

import lombok.Value;

@Value
public class CreateCenterRequest {
    String centre_id;
    String city_id;
}
