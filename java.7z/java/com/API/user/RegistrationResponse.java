package com.API.user;

import lombok.Value;

@Value
public class RegistrationResponse {
    String result;

}