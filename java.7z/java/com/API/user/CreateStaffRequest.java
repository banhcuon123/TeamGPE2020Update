package com.API.user;

import lombok.Value;

@Value
public class CreateStaffRequest {
    String staff_id;
    String city_id;
    String centre_id;
}
