package com.API.user;

import lombok.Value;

@Value
public class CreateCityRequest {
    String city_id;
}
