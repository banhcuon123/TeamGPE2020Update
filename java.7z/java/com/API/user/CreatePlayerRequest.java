package com.API.user;

import lombok.Value;

@Value
public class CreatePlayerRequest {
    String customer_id;
}
