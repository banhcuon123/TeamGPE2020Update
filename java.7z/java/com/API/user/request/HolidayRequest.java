package com.API.user.request;

import lombok.Value;

@Value
public class HolidayRequest {
    String holiday1;
    String holiday2;
    String holiday3;
}
