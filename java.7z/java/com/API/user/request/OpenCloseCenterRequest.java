package com.API.user.request;

import lombok.Value;

@Value
public class OpenCloseCenterRequest {
    String t2;
    String t3;
    String t4;
    String t5;
    String t6;
    String t7;
    String t1;
}
