package com.API.user.request;

import lombok.Value;

@Value
public class MinimumSlotCenterRequest {
    String slot;
}
